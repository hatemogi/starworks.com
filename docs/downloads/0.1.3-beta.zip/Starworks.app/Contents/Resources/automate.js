(function(d, w) {
  "use strict"

  const q = d.querySelector.bind(d),
  앱 = webkit.messageHandlers.starworks

  const 첫페이지설정 = function() {
    w.onMessage = function(m) {
      if (m && m.이름 && m.이메일) {
        // 동의정보 있으면 바로 이동
        q(".goWifi a").click()
      }
    }
    앱.postMessage({action: "동의정보", sender: "첫페이지"})
  }

  const 유효문자열 = function(s) { return s && s.trim().length > 0 }

  const 완료페이지가기 = function() {
    let branch = "unknown"
    let mac = "unknown"
    try { branch = document.forms["Frm2"].branchflag.value } catch (e) {}
    try { mac = document.forms["Frm1"].mac.value } catch (e) {}
    location.href = "http://스타웍스.com/done.html?mac=" + mac + "&branch=" + encodeURIComponent(branch)
  }

  const 동의페이지설정 = function() {
    const f = d.pageForm
    const 동의버튼 = q("img[alt='동의']") || q("img[alt='Agree']")
    const 취소버튼 = q("img[alt='취소']") || q("img[alt='Cancel']")

    if (f && 동의버튼) {
      const 이름 = "userNm", 이메일 = "cust_email_addr", 통신사 = "cust_hp_cp"
      const 한글번호키 = ["phone1", "phone2", "phone3"]
      const 영문번호키 = "cust_hp_no"

      const 기억요청 = function() {
        const fv = function(k) { return f[k] && f[k].value }
        앱.postMessage({
          action: "동의성공", sender: "동의페이지",
          동의정보: {
            이름: fv(이름), 이메일: fv(이메일), 통신사: fv(통신사),
            휴대폰번호: (fv(영문번호키) || 한글번호키.map(fv).filter(유효문자열).join("-")),
            참조: Math.floor(Math.random() * 1234567890).toString(36)
          }
        })
      }

      w.onMessage = function(m) {
        console.log("동의 페이지 응답 받음", m)
        if (m && m.이름 && m.이메일) {
          f[이름].value = m.이름
          f[이메일].value = m.이메일
          f[통신사].value = m.통신사
          if (유효문자열(m.휴대폰번호)) {
            const 번호들 = m.휴대폰번호.split("-")
            if (f[영문번호키]) {
              f[영문번호키] = m.휴대폰번호
            } else {
              한글번호키.forEach(function(키) {
                const 번호 = 번호들.shift()
                if (번호) f[키].value = 번호
              })
            }
          }
          f.agree1 && (f.agree1.checked = true)
          f.agree2 && (f.agree2.checked = true)
          f.참조 = m.참조
          동의버튼.click()
        } else if (m && m.모드 == "개발테스트"){
          취소버튼.addEventListener("click", 기억요청) // 테스트 위해 취소 버튼에 걸었음
        } else if (m && m.동의정보 == "없음") {
          setTimeout(function() {
            alert("스타웍스는 여러분이 작성하는 정보를 기억해서, 다음번부터 자동으로 입력해드립니다.")
          }, 300)
        } else if (m && m.동의성공 == "기록완료") {
          완료페이지가기()
        }
      }

      JSON.parse = (function(prev) {
        // JSON.parse 멍키패치
        return function() {
          let r = prev.apply(JSON, arguments)
          if (r && r.result_cd && (r.result_cd == "0000")) {
            // 인증 성공
            기억요청()
            r.result_cd = "interrupted"
          }
          return r
        }
      })(JSON.parse)

      앱.postMessage({action: "동의정보", sender: "동의페이지"})
      앱.postMessage({action: "모드정보", sender: "동의페이지"})
    }
  }

  const 페이지설정함수 = function() {
    const href = d.location.href
    const 첫페이지패턴 = /index(_en)?_new\.html/,
          동의페이지패턴 = /starbucks_(kr|en)\.php/

    if (첫페이지패턴.test(href)) {
      return 첫페이지설정
    } else if (동의페이지패턴.test(href)) {
      return 동의페이지설정
    } else {
      return function() {
        // hotspot_detect.html은 body가 로드된 다음에 판단하자.
        if (d.body.innerText == "Success") {
          완료페이지가기()
        }
      }
    }
  }

  d.addEventListener("DOMContentLoaded", 페이지설정함수())

  w.onMessage = function() {
    console.log("경고: onMessage 함수 교체됐어야 한다")
  }

})(document, window)
